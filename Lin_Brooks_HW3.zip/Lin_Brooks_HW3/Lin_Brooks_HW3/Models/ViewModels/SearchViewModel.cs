﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace Lin_Brooks_HW3.Models
{
    public enum GreaterOrLess { Greater, Less };
    [Keyless]
    public class SearchViewModel
    {
        [Display(Name = "Search by Title")]
        public String Title { get; set; }
        [Display(Name = "Search by Description")]
        public String Description { get; set; }
        [Display(Name = "Search by Genre: ")]
        public Int32 SelectedGenreID { get; set; }
        [Display(Name = "Search by Rating: ")]
        public Rating SelectedRating { get; set; }
        [Display(Name = "Search by User Rating: ")]
        public Decimal? SearchRating { get; set; }
        public GreaterOrLess UserOption { get; set; }
        [Display(Name = "Search by Published Date: ")]
        public DateTime? SelectedDate { get; set; }


    }
}
