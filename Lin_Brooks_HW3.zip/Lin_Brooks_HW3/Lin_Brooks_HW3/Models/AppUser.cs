﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

//TODO: Update this namespace to match your project
namespace Lin_Brooks_HW3.Models
{
    public class AppUser : IdentityUser { }
}
