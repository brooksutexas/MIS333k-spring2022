﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;


//TODO: Change this using statement to match your project (LastName_FirstName_HW3)
using Lin_Brooks_HW3.DAL;


//TODO: Change this namespace to match your project (LastName_FirstName_HW3)
namespace Lin_Brooks_HW3.Controllers
{
    public class SeedController : Controller
    {
        private AppDbContext _db;

        public SeedController(AppDbContext context)
        {
            _db = context;
        }

        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult SeedGenres()
        {
            try
            {
                Seeding.SeedGenres.SeedAllGenres(_db);
            }
            catch (Exception ex)
            {
                //create new list for all errors
                List<String> errors = new List<String>();

                //add message
                errors.Add("There was an error adding genres to the database!");
                
                //add message from exception
                errors.Add(ex.Message);

                //add message from inner exceptions
                if (ex.InnerException != null)
                { 
                    errors.Add(ex.InnerException.Message);
                    if (ex.InnerException.InnerException != null)
                    {
                        errors.Add(ex.InnerException.InnerException.Message);
                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            errors.Add(ex.InnerException.InnerException.InnerException.Message);
                        }
                    }
                }
                
                //return error message with list of errors
                return View("Error", errors );
            }

            //everything is gucci
            return View("Confirm");
        }

        public IActionResult SeedMovies()
        {
            try
            {
               Seeding.SeedMovies.SeedAllMovies(_db);
            }
            catch (Exception ex)
            {
                //create new list for error messages
                List<String> errors = new List<String>();

                //add error message
                errors.Add("There was a problem adding movies to the database");
                
                //add message from exception
                errors.Add(ex.Message);

                //add message from inner exceptions
                if (ex.InnerException != null)
                {
                    errors.Add(ex.InnerException.Message);
                    if (ex.InnerException.InnerException != null)
                    {
                        errors.Add(ex.InnerException.InnerException.Message);
                        if (ex.InnerException.InnerException.InnerException != null)
                        {
                            errors.Add(ex.InnerException.InnerException.InnerException.Message);
                        }
                    }
                }

                //return error view with errors
                return View("Error", errors);
            }

            //everything is good
            return View("Confirm");
        }
    }
}