﻿using Microsoft.AspNetCore.Mvc;
using Lin_Brooks_HW3.DAL;
using Lin_Brooks_HW3.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace Lin_Brooks_HW3.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context;
        public HomeController(AppDbContext dbContext)
        {
            _context = dbContext;
        }
        // GET: Home
        public IActionResult Index(string SearchString)
        {
            var query = from b in _context.Movies select b; //filter movies
            if (SearchString != null)
            {
                query = query.Where(b => b.Title.Contains(SearchString) || b.Description.Contains(SearchString));
                List<Movie> SelectedMovies = query.Include(b => b.Genre).ToList();
                //Populate the view bag with a count of all movies
                ViewBag.SelectedMovies = SelectedMovies.Count;
                //Populate the view bag with a count of selected movies
                ViewBag.AllMovies = _context.Movies.Count();
                return View(SelectedMovies.OrderBy(s => s.Title));
            }
            else
            {
                List<Movie> SelectedMovies = query.Include(b => b.Genre).ToList();
                ViewBag.SelectedMovies = _context.Movies.Count();
                ViewBag.AllMovies = _context.Movies.Count();
                return View(_context.Movies.OrderBy(s => s.Title));
            }
        }
        public IActionResult Details(int? id) //id of the movie you want
        {
            if (id == null) //MovieID not specified
            {
                //did not specify movieid
                return View("Error", new string[] { "MovieID not specified - which movie do you want to view?" });
            }
            //find movie in the database with id, include the genre
            Movie movie = _context.Movies.Include(b => b.Genre).FirstOrDefault(b => b.MovieID == id);
            if (movie == null)
            {
                return View("Error", new string[] { "Movie not found in database" });
            }
            return View(movie);
        }

        public IActionResult DetailedSearch()
        {
            ViewBag.AllGenres = GetAllGenres();

            SearchViewModel svm = new SearchViewModel();
            svm.SelectedGenreID = 0;
            svm.SelectedRating = 0;

            return View(svm);
        }
        public IActionResult DisplaySearchResults(SearchViewModel svm)
        {
            var query = from b in _context.Movies select b;
            if (svm.Title != null && svm.Title != "") //user entered something
            {
                query = query.Where(b => b.Title.Contains(svm.Title));
            }
            if (svm.Description != null && svm.Description != "")
            {
                query = query.Where(b => b.Description.Contains(svm.Description));
            }
            if (svm.SelectedGenreID != 0)
            {
                Genre GenreToDisplay = _context.Genres.Find(svm.SelectedGenreID);
                query = query.Where(b => b.Genre.Equals(GenreToDisplay));
            }
            if (svm.SelectedRating != 0)
            {
                query = query.Where(b => b.Rating == svm.SelectedRating);
            }
            if (svm.SearchRating != null)
            {
               if (svm.UserOption == GreaterOrLess.Greater)
                {
                    query = query.Where(b => b.VoteAverage >= svm.SearchRating);
                }
               if (svm.UserOption == GreaterOrLess.Less)
                {
                    query = query.Where(b => b.VoteAverage <= svm.SearchRating);
                }
            }
            if (svm.SelectedDate != null)
            {
                query = query.Where(b => b.ReleaseDate >= svm.SelectedDate);
            }

            List<Movie> SelectedMovies = query.Include(b => b.Genre).ToList();
            ViewBag.SelectedMovies = SelectedMovies.Count;
            ViewBag.AllMovies = _context.Movies.Count();
            return View("Index", SelectedMovies.OrderBy(s => s.Title));
        }
        private SelectList GetAllGenres()
        {
            List<Genre> genreList = _context.Genres.ToList();
            Genre SelectNone = new Genre() { GenreID = 0, GenreName = "All Genres" };
            genreList.Add(SelectNone);

            SelectList genreSelectList = new SelectList(genreList.OrderBy(b => b.GenreID), "GenreID", "GenreName");
            return genreSelectList;
        }
    }
}
