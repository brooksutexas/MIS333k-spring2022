﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.IO;

namespace Lin_Brooks_HW1.Controllers
{
    public class HomeController : Controller
    {
        private readonly IWebHostEnvironment _environment;
        public HomeController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Featured()
        {
            return View();
        }

        public IActionResult Resume()
        {
            string path = _environment.WebRootPath + "/files/2022-1-24 LinBrooks_UpdatedResume.pdf";
            var stream = new FileStream(path, FileMode.Open);
            return File(stream, "application/pdf", "2022-1-24 LinBrooks_UpdatedResume.pdf");
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult TCPPresentation()
        {
            string path = _environment.WebRootPath + "/files/00FINAL_UnlockingDOORS_PDF_TCP2021.pptx.pdf";
            var stream = new FileStream(path, FileMode.Open);
            return File(stream, "application/pdf", "00FINAL_UnlockingDOORS_PDF_TCP2021.pptx.pdf");
        }

    }
}
