﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Lin_Brooks_HW5.DAL;
using Lin_Brooks_HW5.Models;
using Microsoft.AspNetCore.Authorization;

namespace Lin_Brooks_HW5.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AppDbContext _context;

        public ProductsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Products
        public async Task<IActionResult> Index()
        {
            return View(await _context.Products.ToListAsync());
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Suppliers)
                .FirstOrDefaultAsync(m => m.ProductID == id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            ViewBag.AllSuppliers = GetAllSuppliers();
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([Bind("ProductID,Name,Description,Price,ProductType")] Product product, int[] SelectedSuppliers)
        {
            ViewBag.AllSuppliers = GetAllSuppliers();

            if (ModelState.IsValid)
            {
                _context.Add(product);
                await _context.SaveChangesAsync();

                foreach (int supplierID in SelectedSuppliers)
                {
                    //Supplier dbSupplier = _context.Suppliers.Find(supplierID);

                    product.Suppliers.Add(_context.Suppliers.Find(supplierID));
                    _context.SaveChanges();
                }

                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }

        // GET: Products/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {

            if (id == null)
            {
                return NotFound();
            }

            Product product = await _context.Products.Include(p => p.Suppliers)
                .FirstOrDefaultAsync(p => p.ProductID == id);


            if (product == null)
            {
                return NotFound();
            }

            ViewBag.AllSuppliers = GetAllSuppliers(product);
            return View(product);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("ProductID,Name,Description,Price,ProductType")] Product product, int[] SelectedSuppliers)
        {

            if (id != product.ProductID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    Product dbproduct = _context.Products
                        .Include(p => p.Suppliers)
                        .FirstOrDefault(p => p.ProductID == product.ProductID);

                    List<Supplier> SuppliersToRemove = new List<Supplier>();

                    foreach (Supplier supplier in dbproduct.Suppliers)
                    {
                        if (SelectedSuppliers.Contains(supplier.SupplierID) == false)
                        {
                            SuppliersToRemove.Add(supplier);
                        }
                    }

                    foreach (Supplier supplier in SuppliersToRemove)
                    {
                        dbproduct.Suppliers.Remove(supplier);
                        _context.SaveChanges();
                    }

                    foreach (int supplierID in SelectedSuppliers)
                    {
                        if (dbproduct.Suppliers.Any(s => s.SupplierID == supplierID) == false)
                        {
                            //Find the associated department in the database
                            Supplier dbSupplier = _context.Suppliers.Find(supplierID);

                            //Add the department to the course's list of departments
                            dbproduct.Suppliers.Add(dbSupplier);
                            _context.SaveChanges();
                        }
                    }

                    dbproduct.Name = product.Name;
                    dbproduct.Description = product.Description;
                    dbproduct.Price = product.Price;
                    dbproduct.ProductType = product.ProductType;


                    _context.Products.Update(dbproduct);
                    _context.SaveChanges();

                    return RedirectToAction(nameof(Index));
                }

                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(product.ProductID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }


            }
            ViewBag.AllSuppliers = GetAllSuppliers();
            return View(product);
        }
        private bool ProductExists(int id)
        {
            return _context.Products.Any(e => e.ProductID == id);
        }

        private SelectList GetAllSuppliers()
        {
            List<Supplier> Suppliers = _context.Suppliers.ToList();
            SelectList supplierSelectList = new SelectList(Suppliers.OrderBy(m => m.SupplierID), "SupplierID", "SupplierName");
            return supplierSelectList;
        }

        private MultiSelectList GetAllSuppliers(Product product)
        {
            List<Supplier> allSuppliers = _context.Suppliers.ToList();

            List<Int32> selectedSupplierIDs = new List<Int32>();

            foreach (Supplier associatedSupplier in product.Suppliers)
            {
                selectedSupplierIDs.Add(associatedSupplier.SupplierID);
            }

            MultiSelectList mslAllSuppliers = new MultiSelectList(allSuppliers.OrderBy(s => s.SupplierName), "SupplierID", "SupplierName", selectedSupplierIDs);

            return mslAllSuppliers;
        }

    }
}
