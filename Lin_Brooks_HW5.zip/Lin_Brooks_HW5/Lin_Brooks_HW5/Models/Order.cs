﻿using Microsoft.AspNetCore.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Lin_Brooks_HW5.Models

{
    public class Order
    {
        //Primary Key
        [Display(Name = "Order ID:")]
        [Required(ErrorMessage = "Order ID is required")]
        public Int32 OrderID { get; set; }

        [Display(Name = "Order Number:")]
        [Required(ErrorMessage = "Order Number is required")]
        public Int32 OrderNumber { get; set; }

        [Display(Name = "Order Date:")]
        [Required(ErrorMessage = "Order Date is required")]
        public DateTime OrderDate { get; set; }

        [Display(Name = "Order Notes:")]
        public String OrderNotes { get; set; }

        [Display(Name = "Order Subtotal")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderSubtotal
        {
            get { return OrderDetails.Sum(orderDetail => orderDetail.ExtendedPrice); }
        }

        [Display(Name = "Sales Tax (8.25%)")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal SalesTax
        {
            get { return OrderSubtotal * TAX_RATE; }
        }

        [Display(Name = "Order Total")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public Decimal OrderTotal
        {
            get { return OrderSubtotal + SalesTax; }
        }

        public const Decimal TAX_RATE = 0.0825m;

        //Navigational Property
        public List<OrderDetail> OrderDetails { get; set; }
        public AppUser AppUser { get; set; }

        public Order()
        {
            if (OrderDetails == null)
            {
                OrderDetails = new List<OrderDetail>();
            }
        }
    }
}
