﻿using Microsoft.AspNetCore.Identity;
using System;
using System.ComponentModel.DataAnnotations;

namespace Lin_Brooks_HW5.Models
{
    public class OrderDetail
    {
        //Primary Key
        [Required(ErrorMessage = "PK is required")]
        public Int32 OrderDetailID { get; set; }
        
        [Display(Name = "Quantity:")]
        [Required(ErrorMessage = "Quantity is required")]
        [Range(1, 1000, ErrorMessage = "Number of products must be between 1 and 1000")]
        public Int32 Quantity { get; set; }
        
        //Product price at time of ordering
        [Display(Name = "Product Price:")]
        [Required(ErrorMessage = "Product price is required")]
        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal ProductPrice { get; set; }



        [DisplayFormat(DataFormatString = "{0:C}")]
        public decimal ExtendedPrice
        {
            get { return Quantity * ProductPrice; }
            set { }
        }


        //Navigational Properties
        public Order Order { get; set; }

        public Product Product { get; set; }

    }
}
