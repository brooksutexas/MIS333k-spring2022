﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Lin_Brooks_HW5.Models
{
    public enum ProductType { hat, pants, sweatshirt, tank, tshirt, other }
    public class Product
    {
        //Primary Key
        [Display(Name = "Product ID:")]
        [Required(ErrorMessage = "Product ID is required")]
        public Int32 ProductID { get; set; }

        [Display(Name = "Product Name:")]
        [Required(ErrorMessage = "Product Name is required")]
        public string Name { get; set; }

        [Display(Name = "Product Description:")]
        public string Description { get; set; }

        [Display(Name = "Product Price:")]
        [Required(ErrorMessage = "Product Price is required")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Price { get; set; }

        [Display(Name = "Product Type:")]
        [Required(ErrorMessage = "Product Type is required")]
        public ProductType ProductType { get; set; }


        //Navigational Properties
        [Display(Name = "Suppliers:")]
        public List<Supplier> Suppliers { get; set; }

        public List<OrderDetail> OrderDetails { get; set; }

        public Product()
        {
            if (Suppliers == null)
            {
                Suppliers = new List<Supplier>();
            }

            if (OrderDetails == null)
            {
                OrderDetails = new List<OrderDetail>();
            }
        }
    }
}
