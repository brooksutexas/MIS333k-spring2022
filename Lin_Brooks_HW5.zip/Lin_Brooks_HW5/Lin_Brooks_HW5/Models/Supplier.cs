﻿using Microsoft.AspNetCore.Identity;
using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace Lin_Brooks_HW5.Models
{
    public class Supplier
    {
        //Primary Key
        [Display(Name = "Supplier ID:")]
        [Required(ErrorMessage = "Supplier ID is required")]
        public Int32 SupplierID { get; set; }

        [Display(Name = "Supplier Name:")]
        [Required(ErrorMessage = "Supplier Name is required")]
        public string SupplierName { get; set; }

        [Display(Name = "Email:")]
        [Required(ErrorMessage = "Phone Number is required")]
        public String Email { get; set; }

        [Display(Name = "Phone Number:")]
        [Required(ErrorMessage = "Phone Number is required")]
        public String Price { get; set; }

        //Navigational Property
        public List<Product> Products { get; set; }

        public Supplier()
        {
            if (Products == null)
            {
                Products = new List<Product>();
            }
        }
    }
}
