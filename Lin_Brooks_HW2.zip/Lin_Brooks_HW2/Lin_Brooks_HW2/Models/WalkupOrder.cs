﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;

namespace Lin_Brooks_HW2.Models
{
    public class WalkupOrder : Order 
    {
        const Decimal SALES_TAX_RATE = .0825m; //sales tax

        [Display(Name = "Customer Name:")] //no rules about customer name
        public String CustomerName { get; set; }

        [Display(Name = "Sales Tax:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal SalesTax { get; set; }

        public void CalcTotals() //calculations
        {
            CalcSubtotals();
            SalesTax = Subtotal * SALES_TAX_RATE;
            Total = Subtotal + SalesTax;
        }
    }
}
