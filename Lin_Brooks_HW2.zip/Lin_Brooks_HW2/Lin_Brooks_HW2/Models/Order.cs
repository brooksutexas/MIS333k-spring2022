﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;

namespace Lin_Brooks_HW2.Models
{
    public enum CustomerType { Walkup, Catering }

    public abstract class Order
    {
        //constants
        const Decimal TACO_PRICE = 2.75m;
        const Decimal BURGER_PRICE = 4.50m;

        //properties
        [Display(Name = "Customer Type")]
        public CustomerType CustomerType { get; set; }


        [Display(Name = "Number of Burgers:")]
        [Range(0, 99999999, ErrorMessage = "Cannot Order a Negative Amount")]
        [Required(ErrorMessage = "Please specify the amount of burgers you wish to order.")]
        public Int32 NumberOfBurgers { get; set; }


        [Display(Name = "Number of Tacos:")]
        [Range(0, 99999999, ErrorMessage = "Cannot Order a Negative Amount")]
        [Required(ErrorMessage = "Please specify the amount of tacos you wish to order.")]
        public Int32 NumberOfTacos { get; set; }


        [Display(Name = "Burger Subtotal:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal BurgerSubtotal { get; set; }


        [Display(Name = "Subtotal:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Subtotal { get; set; }


        [Display(Name = "Taco Subtotal:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal TacoSubtotal { get; set; }


        [Display(Name = "Total:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Total { get; set; }


        [Display(Name = "Total Items:")]
        public Int32 TotalItems { get; set; }

        //method
        public void CalcSubtotals() //calculations
        {
            TotalItems = NumberOfBurgers + NumberOfTacos;
            TacoSubtotal = NumberOfTacos * TACO_PRICE;
            BurgerSubtotal = NumberOfBurgers * BURGER_PRICE;
            Subtotal = TacoSubtotal + BurgerSubtotal;

            if (Subtotal == 0)
            {
                throw new Exception("You must purchase at least one item!");
            }
        }
    }
}
