﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;

namespace Lin_Brooks_HW2.Models
{
    public class CateringOrder : Order 
    {

        [Display(Name = "Customer Code:")]
        [RegularExpression("^[a-zA-Z]+$", ErrorMessage = "Customer code many only contain letters; no numbers or special characters.")]
        [StringLength(4, MinimumLength = 2)] //2-4 characters
        [Required(ErrorMessage = "Customer code is required!")]
        public string CustomerCode { get; set; }

        [Display(Name = "Is this a preferred customer?")]
        public Boolean PreferredCustomer { get; set; }

        [Display(Name = "Delivery Fee:")]
        [Range(0, 250, ErrorMessage = "Delivery fee must be between $0 and $250.")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        [Required(ErrorMessage = "Delivery fee is required!")]
        public Decimal DeliveryFee { get; set; }

        public void CalcTotals() //calculations
        {
            CalcSubtotals();
            
            if (Subtotal > 1000)
            {
                DeliveryFee = 0; //subtotal greater than 1000, delivery fee = 0, even if not preferred customers
            }
            if (PreferredCustomer == true)
            {
                DeliveryFee = 0; //preferred customers always get free delivery
            }

            Total = Subtotal + DeliveryFee;
        }
    }
}
