﻿//Name: Brooks Lin
//Date: 2-18-22
//Description: HW2 - Food Truck Checkout

using Microsoft.AspNetCore.Mvc;
using Lin_Brooks_HW2.Models;
using System;

namespace Lin_Brooks_HW2.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index() //home index
        {
            return View();
        }

        public IActionResult CheckoutCatering() //catering page
        {
            return View();
        }

        public IActionResult CateringTotals(CateringOrder cateringOrder) //create catering order
        {
            cateringOrder.CustomerType = CustomerType.Catering;
            TryValidateModel(cateringOrder);
            if (ModelState.IsValid == false)
            {
                return View("CheckoutCatering", cateringOrder);
            }
            else
            {
                try
                {
                    cateringOrder.CalcTotals();
                }
                catch (Exception ex) //catch exceptions
                {
                    ViewBag.ErrorMessage = ex.Message;
                    return View("CheckoutCatering", cateringOrder);
                }
                return View("CateringTotals", cateringOrder);
            }
        }

        public IActionResult CheckoutWalkup() //walkup page
        {
            return View();
        }

        public IActionResult WalkupTotals(WalkupOrder walkupOrder) //create walkup order
        {
            TryValidateModel(walkupOrder);
            walkupOrder.CustomerType = CustomerType.Walkup;
            if (ModelState.IsValid == false)
            {
                return View("CheckoutWalkup", walkupOrder);
            }
            else
            {
                try
                {
                    walkupOrder.CalcTotals();
                }
                catch (Exception ex) //catch exceptions
                {
                    ViewBag.ErrorMessage = ex.Message;
                    return View("CheckoutWalkup", walkupOrder);
                }
                return View("WalkupTotals", walkupOrder);
            }

        }
    }
}
