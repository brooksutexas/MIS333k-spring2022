﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace Lin_Brooks_HW4.Models
{
    public enum ProductType { Hot, Cold, Packaged, Drink, Other }
    public class Product
    {

        [Required]
        public Int32 ProductID { get; set; }
        [Required]
        public String Name { get; set; }

        public String Description { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Price { get; set; }
        [Required]
        public ProductType Type { get; set; }


    }
}